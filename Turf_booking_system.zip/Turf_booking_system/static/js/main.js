/* ==========================================================================
   PitchPulse User Client-Side Logic
   ========================================================================== */

let currentUser = null;
let currentTurf = null;
let activePaymentMethod = 'Credit/Debit Card';
let selectedDate = null;
let selectedTime = null;
let selectedDuration = null;

document.addEventListener('DOMContentLoaded', () => {
    initSlideshow();
    checkAuthStatus();
    loadTurfs();
    loadFeedbacks();
    setupDateLimits();
    setupFormListeners();
});

// --- 1. DYNAMIC BACKGROUND SLIDESHOW ---
function initSlideshow() {
    const slides = document.querySelectorAll('.bg-slideshow .slide');
    if (slides.length <= 1) return;
    
    let currentSlide = 0;
    setInterval(() => {
        slides[currentSlide].classList.remove('active');
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].classList.add('active');
    }, 6000); // Cross-fade every 6 seconds
}

// --- 2. MODAL MANAGER ---
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden'; // Lock background scroll
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto'; // Unlock scroll
        
        // Reset specific forms if closed
        if (modalId === 'turf-modal') {
            document.getElementById('booking-form').reset();
            document.getElementById('slot-status-box').style.display = 'none';
            document.getElementById('book-proceed-btn').disabled = true;
        }
    }
}

function switchModal(closeId, openId) {
    closeModal(closeId);
    // Add brief delay for smooth animation overlap
    setTimeout(() => {
        openModal(openId);
    }, 150);
}

// Close modal when clicking outside contents
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        closeModal(event.target.id);
    }
};

// --- 3. AUTHENTICATION CLIENT FLOW ---
async function checkAuthStatus() {
    try {
        const response = await fetch('/api/auth/me');
        const data = await response.json();
        
        if (data.success) {
            currentUser = data.user;
            updateAuthUI(true);
            loadUserBookings();
        } else {
            currentUser = null;
            updateAuthUI(false);
        }
    } catch (err) {
        console.error("Auth check failed:", err);
        updateAuthUI(false);
    }
}

function updateAuthUI(isLoggedIn) {
    const authSection = document.getElementById('nav-auth-section');
    const bookingsLink = document.getElementById('nav-bookings-link');
    const bookingsSection = document.getElementById('bookings-section');
    const bookingForm = document.getElementById('booking-form');
    const loginAlert = document.getElementById('booking-login-alert');

    if (isLoggedIn) {
        authSection.innerHTML = `
            <div class="user-name-display">
                <i class="fa-solid fa-circle-user"></i> Hi, ${currentUser.name}
            </div>
            <button class="btn btn-secondary" onclick="handleLogout()">Log Out</button>
        `;
        bookingsLink.style.display = 'inline-block';
        bookingsSection.style.display = 'block';
        if (bookingForm) bookingForm.style.display = 'block';
        if (loginAlert) loginAlert.style.display = 'none';
    } else {
        authSection.innerHTML = `
            <button class="btn btn-secondary" onclick="openModal('login-modal')">Login</button>
            <button class="btn btn-primary" onclick="openModal('register-modal')">Register</button>
        `;
        bookingsLink.style.display = 'none';
        bookingsSection.style.display = 'none';
        if (bookingForm) bookingForm.style.display = 'none';
        if (loginAlert) loginAlert.style.display = 'flex';
    }
}

async function handleRegisterSubmit(e) {
    e.preventDefault();
    const errorBox = document.getElementById('register-error');
    const successBox = document.getElementById('register-success');
    errorBox.style.display = 'none';
    successBox.style.display = 'none';

    const name = document.getElementById('reg-name').value;
    const email = document.getElementById('reg-email').value;
    const mobile = document.getElementById('reg-mobile').value;
    const whatsapp = document.getElementById('reg-whatsapp').value;
    const password = document.getElementById('reg-password').value;

    try {
        const res = await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, mobile, whatsapp, password })
        });
        const data = await res.json();

        if (data.success) {
            successBox.innerText = data.message;
            successBox.style.display = 'block';
            document.getElementById('register-form').reset();
            // Automatically switch to login after 3 seconds
            setTimeout(() => {
                switchModal('register-modal', 'login-modal');
                successBox.style.display = 'none';
            }, 4000);
        } else {
            errorBox.innerText = data.message;
            errorBox.style.display = 'block';
        }
    } catch (err) {
        errorBox.innerText = "Network connection failed. Try again.";
        errorBox.style.display = 'block';
    }
}

async function handleLoginSubmit(e) {
    e.preventDefault();
    const errorBox = document.getElementById('login-error');
    errorBox.style.display = 'none';

    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
        const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();

        if (data.success) {
            currentUser = data.user;
            closeModal('login-modal');
            document.getElementById('login-form').reset();
            updateAuthUI(true);
            loadUserBookings();
            
            // Reload page or parts to ensure stats sync
            window.location.hash = "#turfs-section";
        } else {
            // Requirement 1: Visited first time/wrong credentials shows "Invalid Credential"
            errorBox.innerText = data.message || "Invalid Credential";
            errorBox.style.display = 'block';
        }
    } catch (err) {
        errorBox.innerText = "Invalid Credential"; // default fallback for all login errors as requested
        errorBox.style.display = 'block';
    }
}

async function handleLogout() {
    try {
        await fetch('/api/auth/logout', { method: 'POST' });
        currentUser = null;
        updateAuthUI(false);
        window.location.hash = "#hero";
    } catch (err) {
        console.error("Logout failed:", err);
    }
}

// --- 4. LOAD AND DISPLAY TURFS ---
async function loadTurfs() {
    const container = document.getElementById('turfs-container');
    try {
        const res = await fetch('/api/turfs');
        const data = await res.json();
        
        if (data.success && data.turfs.length > 0) {
            container.innerHTML = '';
            data.turfs.forEach(turf => {
                const facilitiesList = turf.facilities.split(',');
                const tagsHTML = facilitiesList.slice(0, 3).map(f => `<span class="facility-tag">${f.trim()}</span>`).join('');
                
                const card = document.createElement('div');
                card.className = 'turf-card';
                card.innerHTML = `
                    <div class="turf-image-wrapper">
                        <img src="${turf.image_url}" alt="${turf.name}" onerror="this.src='https://images.unsplash.com/photo-1529900748604-07564a03e7a6?auto=format&fit=crop&w=600&q=80'">
                        <span class="turf-rate-tag">₹${turf.hourly_rate} / hr</span>
                    </div>
                    <div class="turf-body">
                        <h3>${turf.name}</h3>
                        <p class="turf-timings"><i class="fa-solid fa-clock"></i> Timings: ${turf.opening_time} - ${turf.closing_time}</p>
                        <div class="facilities-preview">
                            ${tagsHTML}
                            ${facilitiesList.length > 3 ? `<span class="facility-tag">+${facilitiesList.length - 3} more</span>` : ''}
                        </div>
                        <div class="turf-card-footer">
                            <button class="btn btn-primary btn-block" onclick="openTurfDetails(${turf.id})">View Details & Book</button>
                        </div>
                    </div>
                `;
                container.appendChild(card);
            });
        } else {
            container.innerHTML = '<p class="no-data">No turfs available at the moment.</p>';
        }
    } catch (err) {
        console.error("Error loading turfs:", err);
        container.innerHTML = '<p class="no-data">Failed to load turfs. Make sure database is seeded and Flask server is running.</p>';
    }
}

// --- 5. TURF DETAILS AND BOOKING FORMS ---
async function openTurfDetails(turfId) {
    try {
        const res = await fetch(`/api/turfs/${turfId}`);
        const data = await res.json();
        
        if (data.success) {
            currentTurf = data.turf;
            
            // Populate Details UI
            document.getElementById('modal-turf-name').innerText = currentTurf.name;
            document.getElementById('modal-turf-image').src = currentTurf.image_url;
            document.getElementById('modal-turf-rate').innerText = `₹${currentTurf.hourly_rate} / hr`;
            document.getElementById('modal-turf-hours').innerText = `${formatTime(currentTurf.opening_time)} - ${formatTime(currentTurf.closing_time)}`;
            
            const facilitiesList = currentTurf.facilities.split(',');
            const facilitiesUl = document.getElementById('modal-turf-facilities');
            facilitiesUl.innerHTML = facilitiesList.map(f => `<li><i class="fa-solid fa-square-check text-gradient"></i> ${f.trim()}</li>`).join('');
            
            // Reset Booking Form Inputs
            document.getElementById('booking-turf-id').value = currentTurf.id;
            
            // Populate Start Time Selector options based on opening/closing hour bounds
            populateTimeSelector(currentTurf.opening_time, currentTurf.closing_time);
            
            // Setup Default Date to tomorrow
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            document.getElementById('book-date').value = tomorrow.toISOString().split('T')[0];

            updatePriceSummary();
            openModal('turf-modal');
            
            // If logged in, perform initial check
            if (currentUser) {
                checkSlotAvailability();
            }
        }
    } catch (err) {
        alert("Failed to retrieve turf details.");
    }
}

function formatTime(timeStr) {
    // converts 06:00:00 to 06:00 AM
    const parts = timeStr.split(':');
    const hour = parseInt(parts[0]);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 === 0 ? 12 : hour % 12;
    return `${displayHour.toString().padStart(2, '0')}:${parts[1]} ${ampm}`;
}

function populateTimeSelector(openingTime, closingTime) {
    const select = document.getElementById('book-time');
    select.innerHTML = '';
    
    const startHour = parseInt(openingTime.split(':')[0]);
    const endHour = parseInt(closingTime.split(':')[0]);
    
    for (let h = startHour; h < endHour; h++) {
        const option = document.createElement('option');
        option.value = h;
        // Format label
        const displayHour = h % 12 === 0 ? 12 : h % 12;
        const ampm = h >= 12 ? 'PM' : 'AM';
        option.text = `${displayHour.toString().padStart(2, '0')}:00 ${ampm}`;
        select.appendChild(option);
    }
}

function setupDateLimits() {
    const dateInput = document.getElementById('book-date');
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.min = today;
    }
}

function setupFormListeners() {
    const form = document.getElementById('booking-form');
    if (!form) return;
    
    // Auto check availability when form values modify
    ['book-date', 'book-time', 'book-duration'].forEach(id => {
        document.getElementById(id).addEventListener('change', () => {
            updatePriceSummary();
            if (currentUser) {
                checkSlotAvailability();
            }
        });
    });
}

function updatePriceSummary() {
    if (!currentTurf) return;
    
    const duration = parseInt(document.getElementById('book-duration').value) || 1;
    const rate = currentTurf.hourly_rate;
    const total = rate * duration;
    
    document.getElementById('summary-hourly-rate').innerText = `₹${rate}`;
    document.getElementById('summary-duration').innerText = `${duration} Hour${duration > 1 ? 's' : ''}`;
    document.getElementById('summary-total-price').innerText = `₹${total}`;
}

// --- 6. SLOT OVERLAP CHECKING & RECOMMENDATIONS ---
async function checkSlotAvailability() {
    const turfId = document.getElementById('booking-turf-id').value;
    const date = document.getElementById('book-date').value;
    const startHour = document.getElementById('book-time').value;
    const duration = document.getElementById('book-duration').value;
    const statusBox = document.getElementById('slot-status-box');
    const proceedBtn = document.getElementById('book-proceed-btn');

    if (!turfId || !date || startHour === "" || !duration) return;

    statusBox.style.display = 'block';
    statusBox.innerHTML = '<span class="checking-loader"><i class="fa-solid fa-spinner animate-spin"></i> Checking slot availability...</span>';
    proceedBtn.disabled = true;

    try {
        const res = await fetch('/api/bookings/check-slot', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                turf_id: turfId,
                booking_date: date,
                start_hour: startHour,
                duration_hours: duration
            })
        });
        const data = await res.json();

        if (data.success) {
            if (data.available) {
                statusBox.className = 'slot-availability-status available';
                statusBox.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${data.message}`;
                proceedBtn.disabled = false;
            } else {
                statusBox.className = 'slot-availability-status conflict';
                
                // Requirement 4 & 5: Warning "Another team Already Booked turf" + conflicting slots + near slot suggestions
                let recHTML = '';
                if (data.recommendations && data.recommendations.length > 0) {
                    recHTML = `
                        <div class="rec-slots-group">
                            <span style="font-size:12px; display:block; margin-bottom:4px; font-weight:600;">Recommended Slots:</span>
                            ${data.recommendations.map(rec => `
                                <button type="button" class="rec-slot-btn" onclick="selectRecommendedSlot(${rec.start_hour})">
                                    ${rec.label}
                                </button>
                            `).join('')}
                        </div>
                    `;
                }

                statusBox.innerHTML = `
                    <div class="conflict-warning-title"><i class="fa-solid fa-triangle-exclamation"></i> Warning: ${data.message}</div>
                    <p style="font-size:12px;">The slot is booked from <strong>${data.conflicting_slot}</strong>.</p>
                    ${recHTML}
                `;
                proceedBtn.disabled = true;
            }
        }
    } catch (err) {
        statusBox.innerHTML = 'Error checking slot. Try again.';
    }
}

function selectRecommendedSlot(startHour) {
    const select = document.getElementById('book-time');
    select.value = startHour;
    
    // Re-check and update summary
    updatePriceSummary();
    checkSlotAvailability();
}

// --- 7. SIMULATED CHECKOUT & PAYMENTS ---
function handleBookingFormSubmit(e) {
    e.preventDefault();
    if (!currentUser) {
        openModal('login-modal');
        return;
    }
    
    // Save selected values before form reset on closing
    selectedDate = document.getElementById('book-date').value;
    selectedTime = document.getElementById('book-time').value;
    selectedDuration = document.getElementById('book-duration').value;
    
    const totalPrice = document.getElementById('summary-total-price').innerText;
    document.getElementById('payment-total-amount').innerText = totalPrice;
    document.getElementById('qr-amount').innerText = `Payable: ${totalPrice}`;
    
    // Default Tab resets
    switchPaymentTab('card-pay');
    
    // Switch Modal View
    closeModal('turf-modal');
    openModal('payment-modal');
}

function switchPaymentTab(tabId) {
    const tabs = document.querySelectorAll('.payment-tab-btn');
    const panes = document.querySelectorAll('.payment-tab-pane');
    
    panes.forEach(pane => pane.classList.remove('active'));
    tabs.forEach(tab => tab.classList.remove('active'));
    
    document.getElementById(tabId).classList.add('active');
    
    // Set active tab flag based on tabId
    if (tabId === 'card-pay') {
        activePaymentMethod = 'Credit/Debit Card';
        // Add active state to correct button
        tabs[0].classList.add('active');
    } else if (tabId === 'upi-pay') {
        activePaymentMethod = 'UPI';
        tabs[1].classList.add('active');
    } else if (tabId === 'cash-pay') {
        activePaymentMethod = 'Cash';
        tabs[2].classList.add('active');
    }
}

async function processPayment(e, fallbackMethod = '') {
    if (e) e.preventDefault();
    
    const method = fallbackMethod || activePaymentMethod;
    const turfId = currentTurf.id;
    const date = selectedDate;
    const startHour = selectedTime;
    const duration = selectedDuration;

    try {
        const res = await fetch('/api/bookings/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                turf_id: turfId,
                booking_date: date,
                start_hour: startHour,
                duration_hours: duration,
                payment_method: method
            })
        });
        const data = await res.json();

        if (data.success) {
            alert(`Booking Secured! Payment via ${method} registered successfully.`);
            closeModal('payment-modal');
            loadUserBookings();
        } else {
            alert(`Booking failed: ${data.message}`);
        }
    } catch (err) {
        alert("Network transaction error. Please try again.");
    }
}

// --- 8. MY SCHEDULES & CANCELLATIONS ---
async function loadUserBookings() {
    const container = document.getElementById('bookings-container');
    try {
        const res = await fetch('/api/bookings/user');
        const data = await res.json();
        
        if (data.success && data.bookings.length > 0) {
            container.innerHTML = '';
            data.bookings.forEach(b => {
                const isCancelled = b.status === 'Cancelled';
                const dateFormatted = new Date(b.booking_date).toLocaleDateString('en-IN', {
                    day: 'numeric', month: 'short', year: 'numeric'
                });
                
                const card = document.createElement('div');
                card.className = `booking-card status-${b.status.toLowerCase()}`;
                card.innerHTML = `
                    <div class="booking-header">
                        <h3>${b.turf_name}</h3>
                        <span class="booking-id">ID: PP-${b.id}</span>
                    </div>
                    <div class="booking-details-list">
                        <div class="booking-detail-item">
                            <i class="fa-solid fa-calendar-days"></i> ${dateFormatted}
                        </div>
                        <div class="booking-detail-item">
                            <i class="fa-solid fa-clock"></i> Slot: ${String(b.start_hour).padStart(2, '0')}:00 to ${String(b.end_hour).padStart(2, '0')}:00 (${b.duration_hours} hr${b.duration_hours > 1 ? 's' : ''})
                        </div>
                        <div class="booking-detail-item">
                            <i class="fa-solid fa-wallet"></i> Mode: ${b.payment_method} (${b.payment_status})
                        </div>
                        ${isCancelled ? `
                            <div class="booking-detail-item text-danger" style="font-size: 12px; margin-top: 5px;">
                                <i class="fa-solid fa-comment-slash"></i> Reason: "${b.cancellation_reason || 'No reason provided'}"
                            </div>
                        ` : ''}
                    </div>
                    
                    <span class="booking-badge badge-${b.status.toLowerCase()}">${b.status}</span>
                    
                    <div class="booking-actions">
                        <span class="booking-price">₹${b.total_amount}</span>
                        ${!isCancelled ? `<button class="btn btn-secondary btn-outline btn-danger" onclick="triggerCancellation(${b.id})" style="padding: 4px 12px; font-size: 12px;">Cancel Slot</button>` : ''}
                    </div>
                `;
                container.appendChild(card);
            });
        } else {
            container.innerHTML = `
                <div class="no-bookings">
                    <i class="fa-solid fa-calendar-xmark empty-icon"></i>
                    <p>No turf bookings scheduled. Make a slot booking now!</p>
                </div>
            `;
        }
    } catch (err) {
        console.error("Error loading user bookings:", err);
    }
}

function triggerCancellation(bookingId) {
    document.getElementById('cancel-booking-id').value = bookingId;
    document.getElementById('cancel-reason').value = '';
    openModal('cancel-modal');
}

async function handleCancellationSubmit(e) {
    e.preventDefault();
    const bookingId = document.getElementById('cancel-booking-id').value;
    const reason = document.getElementById('cancel-reason').value;

    try {
        const res = await fetch('/api/bookings/cancel', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ booking_id: bookingId, reason: reason })
        });
        const data = await res.json();

        if (data.success) {
            alert(data.message);
            closeModal('cancel-modal');
            loadUserBookings();
        } else {
            alert(`Cancellation failed: ${data.message}`);
        }
    } catch (err) {
        alert("Error in cancellation request.");
    }
}

// --- 9. USER FEEDBACK AND TESTIMONIALS ---
async function loadFeedbacks() {
    const container = document.getElementById('feedback-container');
    try {
        const res = await fetch('/api/feedback/list');
        const data = await res.json();
        
        if (data.success && data.feedbacks.length > 0) {
            container.innerHTML = '';
            data.feedbacks.forEach(f => {
                const starsHTML = '<i class="fa-solid fa-star"></i>'.repeat(f.rating) + '<i class="fa-regular fa-star"></i>'.repeat(5 - f.rating);
                const date = new Date(f.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
                
                const card = document.createElement('div');
                card.className = 'feedback-card';
                card.innerHTML = `
                    <div class="feedback-card-header">
                        <span class="feedback-user">${f.user_name}</span>
                        <span class="feedback-stars">${starsHTML}</span>
                    </div>
                    <p class="feedback-comment">"${f.comments}"</p>
                    <div class="feedback-date">${date}</div>
                `;
                container.appendChild(card);
            });
        } else {
            container.innerHTML = '<p class="feedback-loading">No reviews submitted yet. Be the first to share your experience!</p>';
        }
    } catch (err) {
        container.innerHTML = '<p class="feedback-loading">Failed to sync client feedbacks.</p>';
    }
}

async function handleFeedbackSubmit(e) {
    e.preventDefault();
    if (!currentUser) {
        openModal('login-modal');
        return;
    }

    const ratingOptions = document.getElementsByName('rating');
    let rating = 5;
    for (let option of ratingOptions) {
        if (option.checked) {
            rating = option.value;
            break;
        }
    }
    const comments = document.getElementById('feedback-comments').value;

    try {
        const res = await fetch('/api/feedback/submit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rating, comments })
        });
        const data = await res.json();

        if (data.success) {
            alert(data.message);
            document.getElementById('feedback-form').reset();
            loadFeedbacks();
        } else {
            alert(data.message);
        }
    } catch (err) {
        alert("Failed to submit feedback. Check server connection.");
    }
}

/* ==========================================================================
   PitchPulse Admin Client-Side Logic
   ========================================================================== */

let currentAdmin = null;
let bookingsData = [];
let turfChart = null;

document.addEventListener('DOMContentLoaded', () => {
    checkAdminAuth();
});

// --- 1. ADMIN AUTHENTICATION FLOW ---
async function checkAdminAuth() {
    try {
        const res = await fetch('/api/auth/me');
        const data = await res.json();
        
        // If logged in as admin, show dashboard
        if (data.success && data.user && !data.user.email) { 
            // Admins query 'me' returns admin object without user email field
            currentAdmin = data.user;
            document.getElementById('admin-username-label').innerText = currentAdmin.username;
            document.getElementById('admin-login-overlay').style.display = 'none';
            document.getElementById('admin-dashboard-layout').style.display = 'grid';
            loadAdminStats();
        } else {
            // Show login screen
            showLoginScreen();
        }
    } catch (err) {
        showLoginScreen();
    }
}

function showLoginScreen() {
    document.getElementById('admin-login-overlay').style.display = 'flex';
    document.getElementById('admin-dashboard-layout').style.display = 'none';
}

async function handleAdminLogin(e) {
    e.preventDefault();
    const errorBox = document.getElementById('admin-login-error');
    errorBox.style.display = 'none';

    const username = document.getElementById('admin-user').value;
    const password = document.getElementById('admin-pass').value;

    try {
        const res = await fetch('/api/admin/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();

        if (data.success) {
            currentAdmin = data.admin;
            document.getElementById('admin-username-label').innerText = currentAdmin.username;
            document.getElementById('admin-login-overlay').style.display = 'none';
            document.getElementById('admin-dashboard-layout').style.display = 'grid';
            document.getElementById('admin-login-form').reset();
            loadAdminStats();
        } else {
            errorBox.innerText = "Invalid Credential";
            errorBox.style.display = 'block';
        }
    } catch (err) {
        errorBox.innerText = "Invalid Credential";
        errorBox.style.display = 'block';
    }
}

async function handleAdminLogout() {
    try {
        await fetch('/api/auth/logout', { method: 'POST' });
        currentAdmin = null;
        showLoginScreen();
    } catch (err) {
        console.error("Logout failed:", err);
    }
}

// --- 2. SIDEBAR TAB NAVIGATION ---
function switchAdminTab(tabId) {
    // Switch active buttons
    const buttons = document.querySelectorAll('.sidebar-tab-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    
    // Find matching button
    event.currentTarget.classList.add('active');
    
    // Switch panes
    const panes = document.querySelectorAll('.admin-tab-pane');
    panes.forEach(pane => pane.classList.remove('active'));
    
    document.getElementById(tabId).classList.add('active');
    
    // Update headers
    const title = document.getElementById('page-title');
    const subtitle = document.getElementById('page-subtitle');
    
    if (tabId === 'tab-overview') {
        title.innerText = 'Dashboard Overview';
        subtitle.innerText = 'Real-time bookings, payments, and statistics synced from MySQL server.';
    } else if (tabId === 'tab-bookings') {
        title.innerText = 'Detailed Booking Logs';
        subtitle.innerText = 'View scheduling dates, hourly slots, player mobile numbers, and statuses.';
    } else if (tabId === 'tab-feedback') {
        title.innerText = 'User Feedback & Reviews';
        subtitle.innerText = 'Read ratings and comments submitted by players.';
    } else if (tabId === 'tab-notifications') {
        title.innerText = 'Sent Notifications Console';
        subtitle.innerText = 'Live activity logs of SMS and WhatsApp booking notifications.';
    }
}

// --- 3. FETCH AND SYNC STATS & RENDER CHARTS ---
async function loadAdminStats() {
    try {
        const res = await fetch('/api/admin/stats');
        const data = await res.json();
        
        if (data.success) {
            const stats = data.stats;
            
            // Populate KPI Cards
            document.getElementById('stat-total-bookings').innerText = stats.total_bookings;
            document.getElementById('stat-active-bookings').innerText = stats.active_bookings;
            document.getElementById('stat-cancelled-bookings').innerText = stats.cancelled_bookings;
            document.getElementById('stat-total-revenue').innerText = `₹${stats.total_revenue.toLocaleString('en-IN')}`;
            
            // Populate Arena Stats Table
            populateArenaTable(stats.turf_popularity);
            
            // Render/Update Chart.js Popularity Chart
            renderPopularityChart(stats.turf_popularity);
            
            // Save bookings global data and populate Bookings Table
            bookingsData = stats.bookings_log || [];
            populateBookingsTable(bookingsData);
            
            // Populate feedbacks
            populateFeedbacks(stats.feedbacks || []);
            
            // Populate notification console log
            populateNotificationConsole(stats.notification_logs || []);
        }
    } catch (err) {
        console.error("Error loading admin stats:", err);
    }
}

function populateArenaTable(turfData) {
    const tbody = document.getElementById('admin-turf-stats-body');
    if (!turfData || turfData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" class="table-empty">No turf data registered.</td></tr>';
        return;
    }
    
    tbody.innerHTML = '';
    turfData.forEach(item => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><strong>${item.turf_name}</strong></td>
            <td>${item.booking_count} bookings</td>
            <td><strong>₹${parseInt(item.revenue).toLocaleString('en-IN')}</strong></td>
        `;
        tbody.appendChild(tr);
    });
}

function renderPopularityChart(turfData) {
    const ctx = document.getElementById('chart-turf-popularity').getContext('2d');
    
    const labels = turfData.map(item => item.turf_name);
    const bookings = turfData.map(item => item.booking_count);
    const revenues = turfData.map(item => item.revenue);
    
    if (turfChart) {
        turfChart.destroy();
    }
    
    turfChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Bookings Count',
                    data: bookings,
                    backgroundColor: 'rgba(33, 150, 243, 0.5)',
                    borderColor: 'rgb(33, 150, 243)',
                    borderWidth: 1,
                    yAxisID: 'y'
                },
                {
                    label: 'Revenue (₹)',
                    data: revenues,
                    backgroundColor: 'rgba(76, 239, 80, 0.5)',
                    borderColor: 'rgb(76, 239, 80)',
                    borderWidth: 1,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#f5f6f9', font: { family: 'Outfit' } }
                }
            },
            scales: {
                x: {
                    ticks: { color: '#8a99ad', font: { family: 'Outfit' } },
                    grid: { color: 'rgba(255,255,255,0.05)' }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    ticks: { color: '#8a99ad', font: { family: 'Outfit' } },
                    grid: { color: 'rgba(255,255,255,0.05)' },
                    title: { display: true, text: 'Bookings Count', color: '#8a99ad' }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    ticks: { color: '#8a99ad', font: { family: 'Outfit' } },
                    grid: { drawOnChartArea: false }, // avoid grid overlaps
                    title: { display: true, text: 'Revenue (INR)', color: '#8a99ad' }
                }
            }
        }
    });
}

// --- 4. BOOKING LOG DISPLAY AND FILTERING ---
function populateBookingsTable(bookings) {
    const tbody = document.getElementById('admin-bookings-table-body');
    if (!bookings || bookings.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="table-empty">No bookings records found.</td></tr>';
        return;
    }

    tbody.innerHTML = '';
    bookings.forEach(b => {
        const dateFormatted = new Date(b.booking_date).toLocaleDateString('en-IN', {
            day: 'numeric', month: 'short', year: 'numeric'
        });
        const timeSlot = `${String(b.start_hour).padStart(2, '0')}:00 - ${String(b.end_hour).padStart(2, '0')}:00`;
        const isCancelled = b.status === 'Cancelled';
        
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>#PP-${b.id}</td>
            <td><strong>${b.user_name}</strong></td>
            <td>
                <div><i class="fa-solid fa-phone"></i> ${b.mobile}</div>
                <div><i class="fa-brands fa-whatsapp text-gradient"></i> ${b.whatsapp}</div>
            </td>
            <td>${b.turf_name}</td>
            <td>${dateFormatted}</td>
            <td>${timeSlot}</td>
            <td><strong>₹${b.total_amount}</strong></td>
            <td>${b.payment_method}</td>
            <td>
                <span class="status-pill status-${b.status.toLowerCase()}">${b.status}</span>
                <div style="font-size: 10px; color:#aaa; margin-top:2px;">Pay: ${b.payment_status}</div>
            </td>
            <td>
                ${isCancelled ? `
                    <div style="max-width: 150px; font-size: 11px; color:#ff8a80;" title="${b.cancellation_reason}">
                        <i class="fa-solid fa-comment-slash"></i> Reason: "${b.cancellation_reason}"
                    </div>
                ` : `<span style="color:#555;">No actions</span>`}
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function filterBookingsTable() {
    const val = document.getElementById('booking-search').value.toLowerCase().trim();
    if (val === '') {
        populateBookingsTable(bookingsData);
        return;
    }
    
    const filtered = bookingsData.filter(b => {
        return b.user_name.toLowerCase().includes(val) || 
               b.mobile.includes(val) || 
               b.whatsapp.includes(val) || 
               b.turf_name.toLowerCase().includes(val) ||
               String(b.id).includes(val);
    });
    
    populateBookingsTable(filtered);
}

// --- 5. USER FEEDBACK DISPLAY ---
function populateFeedbacks(feedbacks) {
    const container = document.getElementById('admin-feedback-container');
    if (!feedbacks || feedbacks.length === 0) {
        container.innerHTML = '<div class="feedback-admin-card card-glass"><p>No user feedback submitted yet.</p></div>';
        return;
    }
    
    container.innerHTML = '';
    feedbacks.forEach(f => {
        const starsHTML = '<i class="fa-solid fa-star"></i>'.repeat(f.rating) + '<i class="fa-regular fa-star"></i>'.repeat(5 - f.rating);
        const date = new Date(f.created_at).toLocaleString('en-IN', {
            day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'
        });
        
        const card = document.createElement('div');
        card.className = 'feedback-admin-card card-glass';
        card.innerHTML = `
            <div class="feedback-admin-header">
                <div class="feedback-user-info">
                    <h4>${f.user_name}</h4>
                    <span>${date}</span>
                </div>
                <span class="feedback-stars">${starsHTML}</span>
            </div>
            <p class="feedback-comment">"${f.comments}"</p>
        `;
        container.appendChild(card);
    });
}

// --- 6. NOTIFICATION SYSTEM MONITOR CONSOLE ---
function populateNotificationConsole(logs) {
    const consoleBox = document.getElementById('notification-console-logs');
    if (!logs || logs.length === 0) {
        consoleBox.innerHTML = '<div class="console-line text-muted">No notification logs recorded yet. Reminders are checked every minute...</div>';
        return;
    }
    
    consoleBox.innerHTML = '';
    logs.forEach(line => {
        const consoleLine = document.createElement('div');
        consoleLine.className = 'console-line';
        
        // Highlight critical tags in color
        let text = line.replace(/SMS Sent/g, '<span style="color:#2196f3;">SMS Sent</span>')
                      .replace(/WhatsApp Sent/g, '<span style="color:#00e676;">WhatsApp Sent</span>')
                      .replace(/Your Booking is Waiting/g, '<span style="color:#ffb703;">Your Booking is Waiting</span>');
                      
        consoleLine.innerHTML = text;
        consoleBox.appendChild(consoleLine);
    });
    
    // Auto Scroll to bottom of terminal console
    consoleBox.scrollTop = consoleBox.scrollHeight;
}

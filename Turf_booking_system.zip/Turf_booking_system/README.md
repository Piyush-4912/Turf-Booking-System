# PitchPulse - Premier Turf Booking Management System

PitchPulse is a classy and sporty full-stack Turf Booking Management System. It features a Python Flask backend, a MySQL database, and a highly polished, responsive front-end dashboard.

---

## Key Features
1. **Mandatory Registration**: Mandates Name, Mobile, Email, and WhatsApp number.
2. **Double-Booking Overlap Checker**: Real-time slot conflict warning: `"Another team Already Booked turf"` if schedules overlap.
3. **Smart Slot Recommendation**: Automatically checks nearby available hours on the same day and suggests the two closest options.
4. **Local Email Verification**: Sends activation links. If SMTP is unconfigured, it logs them locally to `sent_emails.txt` for easy copy-pasting during test registrations.
5. **Mock Payments Checkout**: Dynamic credit/debit card forms, UPI QR code simulations, and "Pay at Venue" cash options.
6. **Cancellation Reason Prompts**: Prompts for cancellation reason, updates status to "Cancelled" in the database, refunds payment status, and frees the slot.
7. **Background Notifications Daemon**: Checks bookings every minute and logs alerts to `notifications_sent.log` exactly 1 hour before slots start: `"Your Booking is Waiting For You"`.
8. **Feedback Portal**: Interactive player rating and comment submissions.
9. **Separate Admin Console (`/admin`)**: Clean workspace displaying real-time KPI metrics, booking logs, feedback items, notification streams, and comparative charts (built with Chart.js).

---

## 🛠️ Step-by-Step Setup Instructions

### Step 1: Configure MySQL Credentials
1. Open the configuration file [**`.env`**](file:///d:/YASH/Turf_booking_system/.env).
2. Change the `DB_PASSWORD` value to your local MySQL root password:
   ```env
   DB_PASSWORD=your_mysql_root_password
   ```

### Step 2: Launch the Flask Server
The Flask application is configured to automatically connect to MySQL, create the `pitchpulse_db` database, compile all table structures, seed the default turfs (Camp Nou, Wembley, Lord's), hash admin credentials, and spin up the background notifications thread.

Open a PowerShell or Command Prompt terminal in the project directory and execute:
```powershell
python backend/app.py
```

*Note: If you run into missing package errors, ensure dependencies are installed via `pip install -r requirements.txt`.*

### Step 3: Access the Portals
Once the server starts running on `http://127.0.0.1:5000/`:

* **User Portal**: Open [**`http://127.0.0.1:5000/`**](http://127.0.0.1:5000/) in your browser.
* **Admin Dashboard**: Open [**`http://127.0.0.1:5000/admin`**](http://127.0.0.1:5000/admin) in your browser.

---

## 🔑 Default Credentials & Testing Flow

### 1. Admin Login
* **URL**: `http://127.0.0.1:5000/admin`
* **Username**: `admin`
* **Password**: `AdminPassword123`
* *(These credentials are securely pre-hashed and stored in the database on server startup)*

### 2. User Registration & Email Verification
1. Visit the user portal and click **Register**.
2. Fill out the mandatory fields (Name, Mobile, Email, WhatsApp, Password) and click Submit.
3. Because SMTP details are empty by default, the server will simulate sending an email:
   * Open the generated log file [**`sent_emails.txt`**](file:///d:/YASH/Turf_booking_system/sent_emails.txt) inside the project directory.
   * Copy the verification link (e.g., `http://127.0.0.1:5000/api/auth/verify-email?token=...`).
   * Paste and open the link in a new browser tab. You will see a success screen confirming verification!
4. Return to the user login modal, enter your email and password, and click Log In.

### 3. Slot Booking & Conflict Checks
1. Log in to your user account, click **View Details & Book** on any turf card.
2. Select a booking date, start time, and duration.
3. If the slot is vacant, click **Proceed to Payment**, choose a mock method (Card, UPI QR, or Cash), and submit to secure your slot.
4. Attempt to book another slot overlapping with the same time (e.g., if you booked 4:00 PM to 6:00 PM, try checking 5:00 PM to 6:00 PM on the same turf and date).
5. The system will block it, print the warning `"Another team Already Booked turf"`, and recommend nearby slots. Click a suggestion to automatically reschedule the inputs.

### 4. Hourly Notifications Monitor
1. Book a slot starting exactly **1 hour** from your current local clock time.
2. Within 60 seconds, the background thread in Flask will detect the slot.
3. Open the file [**`notifications_sent.log`**](file:///d:/YASH/Turf_booking_system/notifications_sent.log) to check the logged notification output:
   `Your Booking is Waiting For You`.
4. Navigate to the **Sent Reminders** tab on the Admin dashboard to see the live console log stream update in real-time.

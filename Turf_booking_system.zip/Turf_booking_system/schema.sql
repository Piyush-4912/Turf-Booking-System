-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    mobile VARCHAR(20) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    whatsapp VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    verified TINYINT(1) DEFAULT 0,
    verification_token VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Turfs Table
CREATE TABLE IF NOT EXISTS turfs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    hourly_rate INT NOT NULL,
    opening_time TIME NOT NULL,
    closing_time TIME NOT NULL,
    facilities TEXT NOT NULL, -- Stored as comma-separated values
    image_url VARCHAR(255) NOT NULL
);

-- Bookings Table
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    turf_id INT NOT NULL,
    booking_date DATE NOT NULL,
    start_hour INT NOT NULL, -- 0 to 23
    duration_hours INT NOT NULL,
    end_hour INT NOT NULL, -- start_hour + duration_hours
    total_amount INT NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    payment_status VARCHAR(50) DEFAULT 'Pending',
    status VARCHAR(50) DEFAULT 'Active', -- 'Active', 'Cancelled'
    cancellation_reason TEXT DEFAULT NULL,
    notification_sent TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (turf_id) REFERENCES turfs(id) ON DELETE CASCADE
);

-- Feedback Table
CREATE TABLE IF NOT EXISTS feedbacks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comments TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Admins Table
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed Turf Data
DELETE FROM turfs;
INSERT INTO turfs (id, name, hourly_rate, opening_time, closing_time, facilities, image_url) VALUES
(1, 'Camp Nou Football Turf', 1500, '06:00:00', '23:00:00', 'Premium Artificial Grass,High-intensity Floodlights,Shower & Changing Rooms,Chilled Drinking Water,Free Bibs & Footballs,Ample Parking', '/static/images/turf_camp_nou.png'),
(2, 'Wembley Multi-Sport Arena', 1800, '07:00:00', '22:00:00', 'FIFA Certified Turf,LED Night Floodlights,Locker Rooms,Refuel Cafeteria,Football Boots Rental,First-aid Station', '/static/images/turf_wembley.png'),
(3, 'Lord\'s Indoor Cricket Pitch', 2000, '06:00:00', '23:00:00', 'Professional Cricket Pitch,Net Practice Area,Automatic bowling Machine,Spectator Seating Area,Cricket Kit Rental,Parking', '/static/images/turf_lords.png');

import os
import mysql.connector
from mysql.connector import pooling
from dotenv import load_dotenv
from backend import sheets_db

# Load environment variables
load_dotenv()

DB_TYPE = os.getenv("DB_TYPE", "mysql").lower().strip()
DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_USER = os.getenv("DB_USER", "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_NAME = os.getenv("DB_NAME", "pitchpulse_db")

db_config = {
    "host": DB_HOST,
    "port": DB_PORT,
    "user": DB_USER,
    "password": DB_PASSWORD,
    "database": DB_NAME,
    "raise_on_warnings": False
}

# --- MYSQL CONNECTION POOLING ---
_pool = None

def get_connection():
    global _pool
    if _pool is None:
        try:
            temp_conn = mysql.connector.connect(
                host=DB_HOST,
                port=DB_PORT,
                user=DB_USER,
                password=DB_PASSWORD
            )
            cursor = temp_conn.cursor()
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME}")
            temp_conn.commit()
            cursor.close()
            temp_conn.close()

            _pool = mysql.connector.pooling.MySQLConnectionPool(
                pool_name="pitchpulse_pool",
                pool_size=10,
                **db_config
            )
        except mysql.connector.Error as err:
            print(f"Database connection error: {err}")
            return mysql.connector.connect(**db_config)
    
    return _pool.get_connection()

def query_db(query, args=(), one=False, commit=False):
    """
    Executes a query and returns dictionaries of results or commits a change.
    Only used for MySQL DB_TYPE.
    """
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    rv = None
    try:
        cursor.execute(query, args)
        if commit:
            conn.commit()
            rv = cursor.lastrowid if cursor.lastrowid else cursor.rowcount
        else:
            rv = cursor.fetchall()
            if one:
                rv = rv[0] if rv else None
    except mysql.connector.Error as err:
        print(f"Query error: {err}")
        conn.rollback()
        raise err
    finally:
        cursor.close()
        conn.close()
    return rv

def test_connection():
    if DB_TYPE == "sheets":
        return sheets_db.is_sheets_configured()
    try:
        conn = get_connection()
        conn.close()
        return True
    except Exception as e:
        print(f"Test connection failed: {e}")
        return False


# ==========================================================================
#                   UNIFIED DATABASE ADAPTER FUNCTIONS
# ==========================================================================

# --- 1. USER AUTHENTICATION ---
def get_user_by_email(email):
    if DB_TYPE == "sheets":
        return sheets_db.get_user_by_email(email)
    else:
        return query_db("SELECT * FROM users WHERE email = %s", (email,), one=True)

def get_user_by_id(user_id):
    if DB_TYPE == "sheets":
        return sheets_db.get_user_by_id(user_id)
    else:
        # App expects id, name, email, mobile, whatsapp fields
        return query_db("SELECT id, name, email, mobile, whatsapp FROM users WHERE id = %s", (user_id,), one=True)

def get_user_by_token(token):
    if DB_TYPE == "sheets":
        return sheets_db.get_user_by_token(token)
    else:
        return query_db("SELECT id, name, email FROM users WHERE verification_token = %s", (token,), one=True)

def insert_user(name, mobile, email, whatsapp, password_hash, token):
    if DB_TYPE == "sheets":
        return sheets_db.insert_user(name, mobile, email, whatsapp, password_hash, token)
    else:
        return query_db(
            "INSERT INTO users (name, mobile, email, whatsapp, password_hash, verified, verification_token) VALUES (%s, %s, %s, %s, %s, 0, %s)",
            (name, mobile, email, whatsapp, password_hash, token),
            commit=True
        )

def verify_user_token(token):
    if DB_TYPE == "sheets":
        return sheets_db.verify_user_token(token)
    else:
        query_db("UPDATE users SET verified = 1, verification_token = NULL WHERE verification_token = %s", (token,), commit=True)
        return True

def get_all_users():
    if DB_TYPE == "sheets":
        return sheets_db.get_users()
    else:
        return query_db("SELECT * FROM users")


# --- 2. TURF MANAGEMENT ---
def get_turfs():
    if DB_TYPE == "sheets":
        return sheets_db.get_turfs()
    else:
        return query_db("SELECT * FROM turfs")

def get_turf_by_id(turf_id):
    if DB_TYPE == "sheets":
        return sheets_db.get_turf_by_id(turf_id)
    else:
        return query_db("SELECT * FROM turfs WHERE id = %s", (turf_id,), one=True)


# --- 3. BOOKING ACTIONS ---
def get_bookings():
    if DB_TYPE == "sheets":
        return sheets_db.get_bookings()
    else:
        return query_db("SELECT * FROM bookings")

def insert_booking(user_id, turf_id, booking_date, start_hour, duration_hours, end_hour, total_amount, payment_method, payment_status):
    if DB_TYPE == "sheets":
        return sheets_db.insert_booking(user_id, turf_id, booking_date, start_hour, duration_hours, end_hour, total_amount, payment_method, payment_status)
    else:
        return query_db(
            """INSERT INTO bookings 
               (user_id, turf_id, booking_date, start_hour, duration_hours, end_hour, total_amount, payment_method, payment_status, status) 
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, 'Active')""",
            (user_id, turf_id, booking_date, start_hour, duration_hours, end_hour, total_amount, payment_method, payment_status),
            commit=True
        )

def get_user_bookings(user_id):
    if DB_TYPE == "sheets":
        bookings = sheets_db.get_bookings()
        turfs = sheets_db.get_turfs()
        
        # Create quick map for joins
        turf_map = {t['id']: t for t in turfs}
        
        user_slots = []
        for b in bookings:
            if b['user_id'] == int(user_id):
                t_info = turf_map.get(b['turf_id'], {})
                b['turf_name'] = t_info.get('name', 'Unknown Arena')
                b['image_url'] = t_info.get('image_url', '')
                user_slots.append(b)
                
        # Sort desc
        user_slots.sort(key=lambda x: (x['booking_date'], x['start_hour']), reverse=True)
        return user_slots
    else:
        query = """
            SELECT b.*, t.name as turf_name, t.image_url 
            FROM bookings b
            JOIN turfs t ON b.turf_id = t.id
            WHERE b.user_id = %s
            ORDER BY b.booking_date DESC, b.start_hour DESC
        """
        return query_db(query, (user_id,))

def cancel_booking(booking_id, reason):
    if DB_TYPE == "sheets":
        return sheets_db.update_booking_status(booking_id, "Cancelled", reason, "Refunded")
    else:
        query_db(
            "UPDATE bookings SET status = 'Cancelled', cancellation_reason = %s, payment_status = 'Refunded' WHERE id = %s",
            (reason, booking_id),
            commit=True
        )
        return True

def mark_booking_notification_sent(booking_id):
    if DB_TYPE == "sheets":
        return sheets_db.mark_booking_notification_sent(booking_id)
    else:
        query_db("UPDATE bookings SET notification_sent = 1 WHERE id = %s", (booking_id,), commit=True)
        return True


# --- 4. PLAYER FEEDBACKS ---
def insert_feedback(user_id, rating, comments):
    if DB_TYPE == "sheets":
        return sheets_db.insert_feedback(user_id, rating, comments)
    else:
        return query_db(
            "INSERT INTO feedbacks (user_id, rating, comments) VALUES (%s, %s, %s)",
            (user_id, rating, comments),
            commit=True
        )

def get_feedbacks():
    if DB_TYPE == "sheets":
        feedbacks = sheets_db.get_feedbacks()
        users = sheets_db.get_users()
        user_map = {u['id']: u['name'] for u in users}
        
        for f in feedbacks:
            f['user_name'] = user_map.get(f['user_id'], 'Player')
            
        feedbacks.sort(key=lambda x: x['created_at'], reverse=True)
        return feedbacks
    else:
        query = """
            SELECT f.*, u.name as user_name 
            FROM feedbacks f
            JOIN users u ON f.user_id = u.id
            ORDER BY f.created_at DESC
        """
        return query_db(query)


# --- 5. ADMIN CONTROL ---
def get_admin_by_username(username):
    if DB_TYPE == "sheets":
        return sheets_db.get_admin_by_username(username)
    else:
        return query_db("SELECT * FROM admins WHERE username = %s", (username,), one=True)

def insert_admin(username, password_hash):
    if DB_TYPE == "sheets":
        return sheets_db.insert_admin(username, password_hash)
    else:
        return query_db("INSERT INTO admins (username, password_hash) VALUES (%s, %s)", (username, password_hash), commit=True)

import os
import requests
from dotenv import load_dotenv

load_dotenv()

GOOGLE_SHEET_URL = os.getenv("GOOGLE_SHEET_URL", "")

def is_sheets_configured():
    return bool(GOOGLE_SHEET_URL)

def _get_all_data():
    """
    Fetches all tables in a single HTTP GET request to minimize network overhead.
    """
    if not GOOGLE_SHEET_URL:
        print("GOOGLE_SHEET_URL not set in .env")
        return {}
    try:
        response = requests.get(f"{GOOGLE_SHEET_URL}?action=read_all", timeout=10)
        if response.status_code == 200:
            res_data = response.json()
            if res_data.get("success"):
                return res_data.get("data", {})
            else:
                print(f"Apps Script Error: {res_data.get('message') or res_data.get('error')}")
        else:
            print(f"HTTP GET error: {response.status_code}")
    except Exception as e:
        print(f"Google Sheets connection failed: {e}")
    return {}

def _post_action(action, sheet_name, data=None, key_column=None, key_value=None):
    if not GOOGLE_SHEET_URL:
        return {"success": False, "message": "GOOGLE_SHEET_URL not configured"}
    
    payload = {
        "action": action,
        "sheet": sheet_name
    }
    if data is not None:
        payload["data"] = data
    if key_column is not None:
        payload["key_column"] = key_column
    if key_value is not None:
        payload["key_value"] = key_value

    try:
        response = requests.post(GOOGLE_SHEET_URL, json=payload, timeout=12)
        if response.status_code == 200:
            return response.json()
        else:
            return {"success": False, "message": f"HTTP POST error: {response.status_code}"}
    except Exception as e:
        return {"success": False, "message": str(e)}

# --- USER DATA ADAPTERS ---
def get_users():
    data = _get_all_data()
    users = data.get("users", [])
    for u in users:
        u['id'] = int(u['id'])
        u['verified'] = int(u['verified']) if str(u['verified']).isdigit() else (1 if u['verified'] is True or str(u['verified']).lower() == 'true' else 0)
    return users

def get_user_by_email(email):
    users = get_users()
    for u in users:
        if u['email'].lower() == email.lower().strip():
            return u
    return None

def get_user_by_id(user_id):
    users = get_users()
    for u in users:
        if u['id'] == int(user_id):
            return u
    return None

def get_user_by_token(token):
    users = get_users()
    for u in users:
        if u['verification_token'] == token:
            return u
    return None

def insert_user(name, mobile, email, whatsapp, password_hash, token):
    user_data = {
        "name": name,
        "mobile": mobile,
        "email": email,
        "whatsapp": whatsapp,
        "password_hash": password_hash,
        "verified": 0,
        "verification_token": token
    }
    res = _post_action("append", "users", data=user_data)
    if res.get("success"):
        return int(res["data"]["id"])
    raise Exception(res.get("message") or "Failed to append user")

def verify_user_token(token):
    res = _post_action("update", "users", key_column="verification_token", key_value=token, data={"verified": 1, "verification_token": ""})
    return res.get("success", False)

# --- TURFS DATA ADAPTERS ---
def get_turfs():
    data = _get_all_data()
    turfs = data.get("turfs", [])
    for t in turfs:
        t['id'] = int(t['id'])
        t['hourly_rate'] = int(t['hourly_rate'])
    return turfs

def get_turf_by_id(turf_id):
    turfs = get_turfs()
    for t in turfs:
        if t['id'] == int(turf_id):
            return t
    return None

# --- BOOKINGS DATA ADAPTERS ---
def get_bookings():
    data = _get_all_data()
    bookings = data.get("bookings", [])
    for b in bookings:
        b['id'] = int(b['id'])
        b['user_id'] = int(b['user_id'])
        b['turf_id'] = int(b['turf_id'])
        b['start_hour'] = int(b['start_hour'])
        b['duration_hours'] = int(b['duration_hours'])
        b['end_hour'] = int(b['end_hour'])
        b['total_amount'] = int(b['total_amount'])
        b['notification_sent'] = int(b['notification_sent']) if str(b['notification_sent']).isdigit() else (1 if b['notification_sent'] is True or str(b['notification_sent']).lower() == 'true' else 0)
    return bookings

def insert_booking(user_id, turf_id, booking_date, start_hour, duration_hours, end_hour, total_amount, payment_method, payment_status):
    booking_data = {
        "user_id": int(user_id),
        "turf_id": int(turf_id),
        "booking_date": booking_date,
        "start_hour": int(start_hour),
        "duration_hours": int(duration_hours),
        "end_hour": int(end_hour),
        "total_amount": int(total_amount),
        "payment_method": payment_method,
        "payment_status": payment_status,
        "status": "Active",
        "cancellation_reason": "",
        "notification_sent": 0
    }
    res = _post_action("append", "bookings", data=booking_data)
    if res.get("success"):
        return int(res["data"]["id"])
    raise Exception(res.get("message") or "Failed to append booking")

def update_booking_status(booking_id, status, reason=None, refund_status=None):
    update_data = {"status": status}
    if reason is not None:
        update_data["cancellation_reason"] = reason
    if refund_status is not None:
        update_data["payment_status"] = refund_status
        
    res = _post_action("update", "bookings", key_column="id", key_value=str(booking_id), data=update_data)
    return res.get("success", False)

def mark_booking_notification_sent(booking_id):
    res = _post_action("update", "bookings", key_column="id", key_value=str(booking_id), data={"notification_sent": 1})
    return res.get("success", False)

# --- FEEDBACK DATA ADAPTERS ---
def get_feedbacks():
    data = _get_all_data()
    feedbacks = data.get("feedbacks", [])
    for f in feedbacks:
        f['id'] = int(f['id'])
        f['user_id'] = int(f['user_id'])
        f['rating'] = int(f['rating'])
    return feedbacks

def insert_feedback(user_id, rating, comments):
    feedback_data = {
        "user_id": int(user_id),
        "rating": int(rating),
        "comments": comments
    }
    res = _post_action("append", "feedbacks", data=feedback_data)
    if res.get("success"):
        return int(res["data"]["id"])
    raise Exception(res.get("message") or "Failed to append feedback")

# --- ADMINS DATA ADAPTERS ---
def get_admins():
    data = _get_all_data()
    admins = data.get("admins", [])
    for a in admins:
        a['id'] = int(a['id'])
    return admins

def get_admin_by_username(username):
    admins = get_admins()
    for a in admins:
        if a['username'].lower().strip() == username.lower().strip():
            return a
    return None

def insert_admin(username, password_hash):
    admin_data = {
        "username": username,
        "password_hash": password_hash
    }
    res = _post_action("append", "admins", data=admin_data)
    if res.get("success"):
        return int(res["data"]["id"])
    raise Exception(res.get("message") or "Failed to append admin")

import os
import time
import datetime
import threading
from backend.db import query_db

NOTIFICATION_LOG_PATH = "notifications_sent.log"

def check_and_send_notifications():
    """
    Background job that runs every minute to find bookings starting in exactly 1 hour.
    """
    print("Notification background service started.")
    while True:
        try:
            # Get current date and hour
            now = datetime.datetime.now()
            today_str = now.strftime("%Y-%m-%d")
            
            # The slot hour is exactly now + 1 hour (rounded to nearest hour or simply next hour)
            # In our booking system, slots are booked on hourly bounds (e.g. 16:00 starting at 16)
            # We look for bookings starting in the next hour: start_hour = current_hour + 1
            target_hour = (now.hour + 1) % 24
            
            # If target_hour is 0, we check for tomorrow's date if it rolls over, 
            # but usually turf operating hours are 6:00 to 23:00, so rollover is not common.
            booking_date_target = today_str
            if now.hour == 23:
                # Booking starts at 00:00 tomorrow
                tomorrow = now + datetime.timedelta(days=1)
                booking_date_target = tomorrow.strftime("%Y-%m-%d")
            
            # Fetch bookings and match parameters using the unified database adapter
            from backend import db
            all_bookings = db.get_bookings()
            all_users = db.get_all_users()
            all_turfs = db.get_turfs()
            
            user_map = {u['id']: u for u in all_users}
            turf_map = {t['id']: t for t in all_turfs}
            
            bookings = []
            for b in all_bookings:
                # Safely match date string (works if date is date object or string)
                b_date_str = str(b['booking_date'])
                if (b_date_str == booking_date_target and 
                    int(b['start_hour']) == target_hour and 
                    int(b['notification_sent']) == 0 and 
                    b['status'] == 'Active'):
                    
                    u_info = user_map.get(b['user_id'], {})
                    t_info = turf_map.get(b['turf_id'], {})
                    
                    bookings.append({
                        "id": b['id'],
                        "start_hour": b['start_hour'],
                        "user_name": u_info.get("name", "Player"),
                        "mobile": u_info.get("mobile", ""),
                        "whatsapp": u_info.get("whatsapp", ""),
                        "turf_name": t_info.get("name", "Turf")
                    })
            
            if bookings:
                for b in bookings:
                    booking_id = b['id']
                    user_name = b['user_name']
                    mobile = b['mobile']
                    whatsapp = b['whatsapp']
                    turf_name = b['turf_name']
                    start_hour = b['start_hour']
                    
                    time_str = f"{start_hour:02d}:00"
                    message = f"Your Booking is Waiting For You"
                    
                    # Create simulation log entry
                    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    log_entry = (
                        f"[{timestamp}] [BOOKING #{booking_id}] "
                        f"SMS Sent to {mobile} & WhatsApp Sent to {whatsapp} for user '{user_name}':\n"
                        f"\"Hi {user_name}, {message}! Your slot at '{turf_name}' is booked from {time_str} today. See you soon!\"\n"
                        f"----------------------------------------------------------------------\n"
                    )
                    
                    print(f"\n[NOTIFICATION SERVICE] Triggered for Booking #{booking_id}:\n{log_entry}")
                    
                    # Write to file
                    with open(NOTIFICATION_LOG_PATH, "a", encoding="utf-8") as f:
                        f.write(log_entry)
                        
                    # Mark notification as sent in DB
                    db.mark_booking_notification_sent(booking_id)
                    
        except Exception as e:
            print(f"Error in notification checker thread: {e}")
            
        # Run every 60 seconds
        time.sleep(60)

def start_notification_service():
    thread = threading.Thread(target=check_and_send_notifications, daemon=True)
    thread.start()
    return thread

def get_notification_logs():
    """
    Returns the log lines from notifications_sent.log for the admin page.
    """
    if not os.path.exists(NOTIFICATION_LOG_PATH):
        return []
    try:
        with open(NOTIFICATION_LOG_PATH, "r", encoding="utf-8") as f:
            lines = f.readlines()
        # Parse into structures or just return lines
        return lines[-50:] # Return last 50 log lines
    except Exception as e:
        print(f"Error reading notification logs: {e}")
        return []

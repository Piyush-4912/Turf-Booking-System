import os
import datetime
import bcrypt
from flask import Flask, request, jsonify, session, send_from_directory, render_template_string
from dotenv import load_dotenv
from backend import db
from backend.mail_sender import send_verification_email
from backend.notifications import start_notification_service, get_notification_logs

load_dotenv()

app = Flask(__name__, static_folder="../static", template_folder="../templates")
app.secret_key = os.getenv("SECRET_KEY", "pitchpulse_super_secret_key_1289")

# --- DATABASE AND INITIAL SEEDING ---
def seed_admin_user():
    """
    Checks if admin table is empty and seeds a default admin account.
    """
    if db.DB_TYPE == "sheets":
        # Seeding is handled automatically by the Google Apps Script during setup
        return
    try:
        admins = db.query_db("SELECT * FROM admins LIMIT 1")
        if not admins:
            username = "admin"
            password = "AdminPassword123"
            db.query_db("INSERT INTO admins (username, password_hash) VALUES (%s, %s)", (username, password), commit=True)
            print("============================================================")
            print("DEFAULT ADMIN SEEDED:")
            print(f"Username: {username}")
            print(f"Password: {password}")
            print("============================================================")
    except Exception as e:
        print(f"Error seeding admin: {e}")

def init_db_tables():
    """
    Runs schema.sql if using MySQL and database has no tables.
    """
    if db.DB_TYPE == "sheets":
        # Google Sheets setup handles sheet creation dynamically
        return
    try:
        tables = db.query_db("SHOW TABLES LIKE 'users'")
        if not tables:
            print("Database tables not found. Initializing from schema.sql...")
            schema_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "schema.sql")
            if os.path.exists(schema_path):
                with open(schema_path, "r", encoding="utf-8") as f:
                    schema_sql = f.read()
                
                from backend.db import get_connection
                conn = get_connection()
                cursor = conn.cursor()
                
                queries = schema_sql.split(';')
                for q in queries:
                    clean_q = q.strip()
                    if clean_q:
                        cursor.execute(clean_q)
                        
                conn.commit()
                cursor.close()
                conn.close()
                print("Database tables initialized successfully.")
            else:
                print("Warning: schema.sql file not found.")
    except Exception as e:
        print(f"Error initializing database tables: {e}")

# Initialize
with app.app_context():
    init_db_tables()
    seed_admin_user()
    start_notification_service()

# --- HELPER FUNCTIONS ---
def get_logged_in_user():
    if 'user_id' in session:
        return db.get_user_by_id(session['user_id'])
    return None

def get_logged_in_admin():
    if 'admin_id' in session:
        if db.DB_TYPE == "sheets":
            from backend import sheets_db
            admins = sheets_db.get_admins()
            for a in admins:
                if a['id'] == session['admin_id']:
                    return a
        else:
            return db.query_db("SELECT id, username FROM admins WHERE id = %s", (session['admin_id'],), one=True)
    return None

def parse_time_to_int(time_obj):
    if isinstance(time_obj, datetime.timedelta):
        seconds = time_obj.total_seconds()
        return int(seconds // 3600)
    elif hasattr(time_obj, 'hour'):
        return time_obj.hour
    else:
        try:
            return int(str(time_obj).split(':')[0])
        except:
            return 0

# --- STATIC ROUTING FOR TEMPLATES ---
@app.route('/')
def index_page():
    return send_from_directory(app.template_folder, 'index.html')

@app.route('/admin')
def admin_page():
    return send_from_directory(app.template_folder, 'admin.html')

# --- AUTH API ENDPOINTS ---
@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json or {}
    name = data.get('name', '').strip()
    mobile = data.get('mobile', '').strip()
    email = data.get('email', '').strip()
    whatsapp = data.get('whatsapp', '').strip()
    password = data.get('password', '')

    if not (name and mobile and email and whatsapp and password):
        return jsonify({"success": False, "message": "All fields are mandatory"}), 400

    # Check if user already exists
    existing = db.get_user_by_email(email)
    if existing:
        return jsonify({"success": False, "message": "Email already registered"}), 400

    # Hash password
    password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    # Generate verification token
    import uuid
    verification_token = str(uuid.uuid4())

    try:
        user_id = db.insert_user(name, mobile, email, whatsapp, password_hash, verification_token)
        
        # Send confirmation email
        send_verification_email(email, name, verification_token)
        
        return jsonify({
            "success": True, 
            "message": "Registration successful! A confirmation email has been sent. Please verify your account before logging in."
        })
    except Exception as e:
        return jsonify({"success": False, "message": f"Database error: {str(e)}"}), 500

@app.route('/api/auth/verify-email', methods=['GET'])
def verify_email():
    token = request.args.get('token', '')
    if not token:
        return "Invalid or missing token", 400
    
    user = db.get_user_by_token(token)
    if not user:
        return render_template_string("""
            <html>
                <body style="font-family: sans-serif; text-align: center; padding: 50px; background: #121212; color: #ff5555;">
                    <h2>Invalid or Expired Verification Link</h2>
                    <p>The verification token could not be found. Please register again or contact support.</p>
                    <a href="/" style="color: #4caf50; text-decoration: none;">Go to PitchPulse Home</a>
                </body>
            </html>
        """)

    try:
        db.verify_user_token(token)
        return render_template_string(f"""
            <html>
                <body style="font-family: sans-serif; text-align: center; padding: 50px; background: #121212; color: #e0e0e0;">
                    <div style="max-width: 500px; margin: auto; padding: 30px; background: #1e1e1e; border-radius: 10px; border: 1px solid #4caf50;">
                        <h2 style="color: #4caf50;">Email Verified Successfully!</h2>
                        <p>Hi {user['name']}, your account ({user['email']}) is now active.</p>
                        <p>You can close this tab and log in to the PitchPulse system.</p>
                        <a href="/" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background: #4caf50; color: #fff; text-decoration: none; border-radius: 5px; font-weight: bold;">Login Now</a>
                    </div>
                </body>
            </html>
        """)
    except Exception as e:
        return f"Verification database update failed: {e}", 500

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json or {}
    email = data.get('email', '').strip()
    password = data.get('password', '')

    if not (email and password):
        return jsonify({"success": False, "message": "Invalid Credential"}), 400

    user = db.get_user_by_email(email)
    
    # If user does not exist or credentials mismatch: return "Invalid Credential"
    if not user:
        return jsonify({"success": False, "message": "Invalid Credential"}), 400

    if not bcrypt.checkpw(password.encode('utf-8'), user['password_hash'].encode('utf-8')):
        return jsonify({"success": False, "message": "Invalid Credential"}), 400

    # Check if email is verified
    # Sheets sometimes return string "0" or "1"
    is_verified = int(user['verified']) if str(user['verified']).isdigit() else (1 if user['verified'] is True or str(user['verified']).lower() == 'true' else 0)
    if not is_verified:
        return jsonify({
            "success": False, 
            "message": "Account not verified. Please check your email inbox (or sent_emails.txt) for the verification link."
        }), 401

    session['user_id'] = user['id']
    session['role'] = 'user'
    
    return jsonify({
        "success": True,
        "user": {
            "id": user['id'],
            "name": user['name'],
            "email": user['email']
        }
    })

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({"success": True, "message": "Logged out successfully"})

@app.route('/api/auth/me', methods=['GET'])
def get_me():
    user = get_logged_in_user()
    if user:
        return jsonify({"success": True, "user": user})
    return jsonify({"success": False, "message": "Not authenticated"}), 401

# --- TURFS API ENDPOINTS ---
@app.route('/api/turfs', methods=['GET'])
def list_turfs():
    turfs = db.get_turfs()
    for t in turfs:
        t['opening_time'] = str(t['opening_time'])[:5]
        t['closing_time'] = str(t['closing_time'])[:5]
    return jsonify({"success": True, "turfs": turfs})

@app.route('/api/turfs/<int:turf_id>', methods=['GET'])
def get_turf(turf_id):
    turf = db.get_turf_by_id(turf_id)
    if turf:
        turf['opening_time'] = str(turf['opening_time'])[:5]
        turf['closing_time'] = str(turf['closing_time'])[:5]
        return jsonify({"success": True, "turf": turf})
    return jsonify({"success": False, "message": "Turf not found"}), 404

# --- BOOKING API ENDPOINTS ---
@app.route('/api/bookings/check-slot', methods=['POST'])
def check_slot():
    data = request.json or {}
    turf_id = data.get('turf_id')
    booking_date = data.get('booking_date')
    start_hour = data.get('start_hour')
    duration_hours = data.get('duration_hours')

    if not (turf_id and booking_date and start_hour is not None and duration_hours):
        return jsonify({"success": False, "message": "Missing booking details"}), 400

    try:
        start_hour = int(start_hour)
        duration_hours = int(duration_hours)
        end_hour = start_hour + duration_hours
    except ValueError:
        return jsonify({"success": False, "message": "Invalid time or duration format"}), 400

    # Get turf details to verify operating hours
    turf = db.get_turf_by_id(turf_id)
    if not turf:
        return jsonify({"success": False, "message": "Turf not found"}), 404
        
    opening_hour = parse_time_to_int(turf['opening_time'])
    closing_hour = parse_time_to_int(turf['closing_time'])

    if start_hour < opening_hour or end_hour > closing_hour:
        return jsonify({
            "success": False, 
            "available": False,
            "message": f"Turf operates between {opening_hour:02d}:00 and {closing_hour:02d}:00."
        })

    # Check conflicts in Python (compatible with both MySQL and Google Sheets)
    all_bookings = db.get_bookings()
    conflicts = []
    for b in all_bookings:
        b_date_str = str(b['booking_date'])
        if (b['turf_id'] == int(turf_id) and 
            b_date_str == str(booking_date) and 
            b['status'] == 'Active'):
            if not (start_hour >= b['end_hour'] or end_hour <= b['start_hour']):
                conflicts.append(b)

    if conflicts:
        conflict = conflicts[0]
        conflicting_time = f"{conflict['start_hour']:02d}:00 to {conflict['end_hour']:02d}:00"
        
        # Suggest alternative slots
        recommendations = recommend_slots(turf_id, booking_date, start_hour, duration_hours, opening_hour, closing_hour)
        
        return jsonify({
            "success": True,
            "available": False,
            "message": "Another team Already Booked turf",
            "conflicting_slot": conflicting_time,
            "recommendations": recommendations
        })

    return jsonify({"success": True, "available": True, "message": "Slot is available!"})

def recommend_slots(turf_id, booking_date, desired_start, duration, opening_hour, closing_hour):
    """
    Finds nearest available slots on the same day.
    """
    all_bookings = db.get_bookings()
    bookings = []
    for b in all_bookings:
        b_date_str = str(b['booking_date'])
        if b['turf_id'] == int(turf_id) and b_date_str == str(booking_date) and b['status'] == 'Active':
            bookings.append(b)
    
    # Generate all candidate start hours
    available_starts = []
    max_start = closing_hour - duration
    
    for candidate_start in range(opening_hour, max_start + 1):
        candidate_end = candidate_start + duration
        
        overlaps = False
        for b in bookings:
            if not (candidate_start >= b['end_hour'] or candidate_end <= b['start_hour']):
                overlaps = True
                break
        
        if not overlaps:
            available_starts.append(candidate_start)
            
    if not available_starts:
        return []
        
    # Sort candidate start hours by proximity to desired start
    available_starts.sort(key=lambda x: abs(x - desired_start))
    
    # Return top 2 recommendations formatted as string slots
    recommendations = []
    for start in available_starts[:2]:
        recommendations.append({
            "start_hour": start,
            "end_hour": start + duration,
            "label": f"{start:02d}:00 - {start + duration:02d}:00"
        })
        
    return recommendations

@app.route('/api/bookings/create', methods=['POST'])
def create_booking():
    user = get_logged_in_user()
    if not user:
        return jsonify({"success": False, "message": "Unauthorized"}), 401

    data = request.json or {}
    turf_id = data.get('turf_id')
    booking_date = data.get('booking_date')
    start_hour = int(data.get('start_hour'))
    duration_hours = int(data.get('duration_hours'))
    payment_method = data.get('payment_method', 'Cash')

    # Get rate and check validity
    turf = db.get_turf_by_id(turf_id)
    if not turf:
        return jsonify({"success": False, "message": "Turf not found"}), 404

    opening_hour = parse_time_to_int(turf['opening_time'])
    closing_hour = parse_time_to_int(turf['closing_time'])
    end_hour = start_hour + duration_hours

    if start_hour < opening_hour or end_hour > closing_hour:
        return jsonify({"success": False, "message": "Time selection falls outside operating hours"}), 400

    # Overlap Double Check
    all_bookings = db.get_bookings()
    conflicts = []
    for b in all_bookings:
        b_date_str = str(b['booking_date'])
        if (b['turf_id'] == int(turf_id) and 
            b_date_str == str(booking_date) and 
            b['status'] == 'Active'):
            if not (start_hour >= b['end_hour'] or end_hour <= b['start_hour']):
                conflicts.append(b)
                
    if conflicts:
        return jsonify({"success": False, "message": "Another team Already Booked turf"}), 400

    # Calculate Total amount
    total_amount = turf['hourly_rate'] * duration_hours
    
    # Determine initial payment status (UPI/Cards are immediately 'Paid' in this simulated checkout; Cash is 'Pending')
    payment_status = "Paid" if payment_method in ["UPI", "Credit Card", "Debit Card", "QR Code"] else "Pending"

    try:
        booking_id = db.insert_booking(user['id'], turf_id, booking_date, start_hour, duration_hours, end_hour, total_amount, payment_method, payment_status)
        return jsonify({
            "success": True,
            "message": "Booking successful! Your slot is secured.",
            "booking_id": booking_id
        })
    except Exception as e:
        return jsonify({"success": False, "message": f"Database insertion failed: {e}"}), 500

@app.route('/api/bookings/user', methods=['GET'])
def get_user_bookings():
    user = get_logged_in_user()
    if not user:
        return jsonify({"success": False, "message": "Unauthorized"}), 401

    bookings = db.get_user_bookings(user['id'])
    for b in bookings:
        b['booking_date'] = str(b['booking_date'])
    return jsonify({"success": True, "bookings": bookings})

@app.route('/api/bookings/cancel', methods=['POST'])
def cancel_booking():
    user = get_logged_in_user()
    if not user:
        return jsonify({"success": False, "message": "Unauthorized"}), 401

    data = request.json or {}
    booking_id = data.get('booking_id')
    reason = data.get('reason', '').strip()

    if not booking_id or not reason:
        return jsonify({"success": False, "message": "Booking ID and cancellation reason are required"}), 400

    # Verify ownership
    all_bookings = db.get_bookings()
    booking = None
    for b in all_bookings:
        if b['id'] == int(booking_id) and b['user_id'] == int(user['id']):
            booking = b
            break
            
    if not booking:
        return jsonify({"success": False, "message": "Booking not found or access denied"}), 404

    if booking['status'] == 'Cancelled':
        return jsonify({"success": False, "message": "Booking is already cancelled"}), 400

    try:
        db.cancel_booking(booking_id, reason)
        return jsonify({"success": True, "message": "Booking cancelled successfully! Slot released."})
    except Exception as e:
        return jsonify({"success": False, "message": f"Database update failed: {e}"}), 500

# --- FEEDBACK API ENDPOINTS ---
@app.route('/api/feedback/submit', methods=['POST'])
def submit_feedback():
    user = get_logged_in_user()
    if not user:
        return jsonify({"success": False, "message": "Unauthorized. Please login to submit feedback."}), 401

    data = request.json or {}
    rating = data.get('rating')
    comments = data.get('comments', '').strip()

    if not rating or not comments:
        return jsonify({"success": False, "message": "Rating and comments are required"}), 400

    try:
        rating = int(rating)
        if not (1 <= rating <= 5):
            raise ValueError()
    except ValueError:
        return jsonify({"success": False, "message": "Rating must be an integer between 1 and 5"}), 400

    try:
        db.insert_feedback(user['id'], rating, comments)
        return jsonify({"success": True, "message": "Thank you for your feedback!"})
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to submit feedback: {e}"}), 500

@app.route('/api/feedback/list', methods=['GET'])
def list_feedback():
    feedbacks = db.get_feedbacks()
    for f in feedbacks:
        f['created_at'] = str(f['created_at'])
    return jsonify({"success": True, "feedbacks": feedbacks})

# --- ADMIN API ENDPOINTS ---
@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    data = request.json or {}
    username = data.get('username', '').strip()
    password = data.get('password', '')

    if not (username and password):
        return jsonify({"success": False, "message": "Admin credentials required"}), 400

    admin = db.get_admin_by_username(username)
    if not admin:
        return jsonify({"success": False, "message": "Invalid Credential"}), 400

    if admin['password_hash'] != password:
        return jsonify({"success": False, "message": "Invalid Credential"}), 400

    session['admin_id'] = admin['id']
    session['role'] = 'admin'
    return jsonify({"success": True, "admin": {"id": admin['id'], "username": admin['username']}})

@app.route('/api/admin/stats', methods=['GET'])
def get_admin_stats():
    admin = get_logged_in_admin()
    if not admin:
        return jsonify({"success": False, "message": "Unauthorized"}), 401

    try:
        # Load all datasets for Python-side joins and metrics calculations
        all_bookings = db.get_bookings()
        all_feedbacks = db.get_feedbacks()
        all_turfs = db.get_turfs()
        all_users = db.get_all_users()
        
        user_map = {u['id']: u for u in all_users}
        turf_map = {t['id']: t for t in all_turfs}

        # Calculate statistics
        total_bookings = len(all_bookings)
        active_bookings = sum(1 for b in all_bookings if b['status'] == 'Active')
        cancelled_bookings = sum(1 for b in all_bookings if b['status'] == 'Cancelled')
        total_revenue = sum(b['total_amount'] for b in all_bookings if b['status'] == 'Active' and b['payment_status'] == 'Paid')
        feedback_count = len(all_feedbacks)

        # Popularity stats
        turf_popularity_dict = {t['id']: {"turf_name": t['name'], "booking_count": 0, "revenue": 0} for t in all_turfs}
        for b in all_bookings:
            t_id = b['turf_id']
            if t_id in turf_popularity_dict:
                turf_popularity_dict[t_id]["booking_count"] += 1
                if b['status'] == 'Active':
                    turf_popularity_dict[t_id]["revenue"] += b['total_amount']

        turf_popularity = list(turf_popularity_dict.values())

        # Bookings detailed log
        bookings_log = []
        for b in all_bookings:
            u_info = user_map.get(b['user_id'], {})
            t_info = turf_map.get(b['turf_id'], {})
            
            bookings_log.append({
                "id": b['id'],
                "user_name": u_info.get("name", "Player"),
                "mobile": u_info.get("mobile", ""),
                "whatsapp": u_info.get("whatsapp", ""),
                "turf_name": t_info.get("name", "Arena"),
                "booking_date": str(b['booking_date']),
                "start_hour": b['start_hour'],
                "end_hour": b['end_hour'],
                "total_amount": b['total_amount'],
                "payment_method": b['payment_method'],
                "payment_status": b['payment_status'],
                "status": b['status'],
                "cancellation_reason": b['cancellation_reason']
            })

        # Sort logs descending
        bookings_log.sort(key=lambda x: x['id'], reverse=True)

        # Notification Logs
        notification_logs = get_notification_logs()

        return jsonify({
            "success": True,
            "stats": {
                "total_bookings": total_bookings,
                "active_bookings": active_bookings,
                "cancelled_bookings": cancelled_bookings,
                "total_revenue": int(total_revenue),
                "feedback_count": feedback_count,
                "turf_popularity": turf_popularity,
                "bookings_log": bookings_log,
                "notification_logs": notification_logs
            }
        })
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to retrieve stats: {e}"}), 500

if __name__ == '__main__':
    print(f"Testing DB connection (Type: {db.DB_TYPE})...")
    if db.test_connection():
        print("Database connection verified successfully!")
    else:
        print("CRITICAL WARNING: Database connection failed. Please check credentials in your .env configuration.")
    
    app.run(host='0.0.0.0', port=5000, debug=True)

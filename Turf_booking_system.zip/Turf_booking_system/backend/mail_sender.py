import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv

load_dotenv()

SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "").replace(" ", "")
SMTP_FROM = os.getenv("SMTP_FROM", "noreply@pitchpulse.com")

def send_verification_email(user_email, user_name, token):
    verification_link = f"http://127.0.0.1:5000/api/auth/verify-email?token={token}"
    
    subject = "Verify Your PitchPulse Account"
    
    body = f"""Hi {user_name},

Thank you for registering at PitchPulse! To complete your registration and log in, please verify your email address by clicking the link below:

{verification_link}

If you did not register for a PitchPulse account, please ignore this email.

Best regards,
The PitchPulse Team
"""
    
    # Try sending via real SMTP if credentials are provided
    if SMTP_USER and SMTP_PASSWORD:
        try:
            msg = MIMEMultipart()
            msg['From'] = SMTP_FROM
            msg['To'] = user_email
            msg['Subject'] = subject
            
            msg.attach(MIMEText(body, 'plain'))
            
            server = smtplib.SMTP(SMTP_HOST, SMTP_PORT)
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.sendmail(SMTP_FROM, user_email, msg.as_string())
            server.quit()
            print(f"Verification email successfully sent to {user_email}")
            return True
        except Exception as e:
            print(f"SMTP sending failed: {e}. Falling back to simulation.")
    
    # Fallback simulation
    sim_entry = f"""
============================================================
[SIMULATED EMAIL SENT]
Timestamp: {os.times()}
To: {user_email} ({user_name})
Subject: {subject}
------------------------------------------------------------
{body}
============================================================
"""
    print(sim_entry)
    
    # Write to local file so user can access link easily
    try:
        with open("sent_emails.txt", "a", encoding="utf-8") as f:
            f.write(sim_entry)
    except Exception as log_err:
        print(f"Error logging email to file: {log_err}")
        
    return True
